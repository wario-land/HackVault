Wario Land 4: Time Attack Edition ver1.4
by beco(https://www.twitch.tv/beco)

[How to play]
Patch "WL4_TimeAttackEdition_v1.4.bps" to a vanilla Wario Land 4(US) rom

[Features]
- Timer is always on top-right of screen in level (replaced coin display, it shows Minutes'Seconds'Frames)
* Timer doesn't include lag frames
* Insta-death when run out of the frog timer due to coin display replacement

- For a level, best time will be saved when escape with all four jewel pieces and Keyzer for each level/difficulty
- Taking the lap time for each jewel piece and Keyzer and will be saved when escape with best time
- Timer blinks when beating the best time
* To clear all best times, hold L+R when booting the game

- Retry current level from pause menu
- Change difficulty (press SELECT in the passage screen)
- Faster movement in the map screen
- Shorter cutscenes

[Known issues]
- In boss level, pause/unpause cuts off the BGM and messes up the boss life bar display

[Credits]
Special thanks to:
- mpu
- WL4Editor developers

[Update history]
2021/09/26 v1.4
- Added lap time feature (taking the lap time for each jewel piece and Keyzer)
- Improved: now beating boss doesn't change the map position
- Improved: now reset doesn't initialize difficulty to Normal

2021/09/11 v1.3
- Supported boss fights
- Improved timer, changed start timing

2020/12/14 v1.2
- Bug fixed: restore the frog timer for level retry
- Bug fixed: stable best time update

2020/12/14 v1.1
- Now timer keep running during pausing or screen transitions for RTA-viable

2020/12/13 v1.0
- Initial release