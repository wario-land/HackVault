Wario Land 4: Magic Crystals ver0.1
by beco (https://www.twitch.tv/beco)

[How to play]
Patch "Wario_Land_4_Magic_Crystals_ver0.1.bps" to a vanilla Wario Land 4(US) rom
You can patch on this website: https://wario-land.github.io/HackVault/patch.html

[Credits]
- WL4Editor developers for awesome tool  
- ssp for patches  
- Blanchon for patches  

[Update history]
2022/11/18 v0.1 (Initial release)
- Edited Entry Passage and Emerald Passage(first level)
