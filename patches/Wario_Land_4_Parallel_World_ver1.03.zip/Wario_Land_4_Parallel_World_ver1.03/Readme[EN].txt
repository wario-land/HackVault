Wario Land 4: Parallel_World ver1.03
by beco(https://www.twitch.tv/beco)

[How to play]
Patch "Wario_Land_4_Parallel_World_ver1.03(US).bps" to a vanilla Wario Land 4(US) rom
You can patch on this website: https://wario-land.github.io/HackVault/patch.html

[Credits]
I'm able to hack the game thanks to WL4Editor, very useful and user-friendly tool
Huge appreciation for tool authors and Wario Land 4 hack community!

[Recommended Emulator/Flash Cart]
- mGBA
- BizHawk
- EverDrive-GBA X5
* VisualBoyAdvance is not recommended for this hack, it gets very laggy on escape sequence for some reason

[Update history]
2021/08/27 v1.03
- Made adjustments in some levels

2021/08/24 v1.02
- Fixed few details in some levels

2021/08/21 v1.01
- Fixed a door setting in Emerald level 2

2021/08/21 v1.0
- Edited Topaz and Golden Passage (Complete!)
- Made adjustments on almost every level
- More custom graphics/music

2020/11/30 v0.71
- Fixed diamond counter bugs
- Made adjustments on some levels

2020/11/29 v0.7
- Edited Ruby Passage
- Added diamond counter
- Added the escape rooms in Sapphire level 4
- Made adjustments on some levels
- Custom CDs (Replaced with other game OST, not edited album title/art yet)
- S-hard available (for debugging purposes, will be disabled in ver1.0 release)

2020/08/18 v0.41
- Fixed some little stuff in Sapphire level 1

2020/08/18 v0.4
- Edited Sapphire Passage
- Added some custom graphics/musics

2020/05/20 v0.22
- Fixed the door settings in Room 8 of Emerald level 3

2020/05/20 v0.21
- Fixed the terrain in Room 12 of Emerald level 4

2020/05/20 v0.2 (Initial release)
- Edited Entry Passage and Emerald Passage
