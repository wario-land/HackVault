Wario Land 4: Time Attack Edition ver1.5
by beco(https://www.twitch.tv/beco)

[How to play]
Patch "WL4_TimeAttackEdition_v1.5.bps" to a vanilla Wario Land 4(US) rom

[Features]
- Timer is always on top-right of screen in level (replaced coin display,counts up to 99 minutes, 59 seconds, 59 frames)
* Toggle display between Minutes'Seconds'Frames and Minutes'Seconds''MilliSeconds (press START in the passage screen)
* Timer DOES include lag frames (v1.5 update)
* Insta-death when run out of the frog timer due to coin display replacement

- For a level, best time will be saved when escape with all four jewel pieces and Keyzer for each level/difficulty
- Taking the lap time for each jewel piece and Keyzer and will be saved when escape with best time
- Timer blinks when beating the best time
* To clear all best times, hold L+R when booting the game

- Retry current level from pause menu
- Change difficulty (press SELECT in the passage screen)
- Faster movement in the map screen
- Shorter cutscenes

[Credits]
Special thanks to:
- mpu for patches (ASM)
- WL4Editor developers for awesome tool

[Update history]
2023/02/28 v1.5
- Added timer display toggle feature
- Improved: now timer does include lag frames
- Improved: no more level intro/outro cutscenes
- Bug fixed: all boss movement cycles are synced to vanilla
- Bug fixed: pause/unpause doesn't mess up BGM and graphics in boss level

2021/09/26 v1.4
- Added lap time feature (taking the lap time for each jewel piece and Keyzer)
- Improved: now beating boss doesn't change the map position
- Improved: now reset doesn't initialize difficulty to Normal

2021/09/11 v1.3
- Supported boss fights
- Improved timer, changed start timing

2020/12/14 v1.2
- Bug fixed: restore the frog timer for level retry
- Bug fixed: stable best time update

2020/12/14 v1.1
- Now timer keep running during pausing or screen transitions for RTA-viable

2020/12/13 v1.0
- Initial release