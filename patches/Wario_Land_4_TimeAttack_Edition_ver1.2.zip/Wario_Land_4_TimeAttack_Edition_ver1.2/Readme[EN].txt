Wario Land 4: Time Attack Edition ver1.2
by beco(https://www.twitch.tv/beco)

[How to play]
Patch "WL4_TimeAttackEdition_v1.2.bps" to a vanilla Wario Land 4(US) rom

[Features]
- Timer is always on top-right of screen in level (replaced coin display)
* For now, timer doesn't include lag frames (v1.2)
* For now, not supporting boss levels (v1.2)
* Insta-death when run out of the frog timer due to coin display replacement

- Best time will be saved when escape with all four jewel pieces and Keyzer for each level/difficulty
* To clear all best times, hold L+R when boot the game

- Retry current level from pause menu
- Change difficulty (press SELECT in the passage screen)
- Shorter cutscenes

[Credits]
Special thanks to:
- mpu
- WL4Editor developers

[ToDo]
- Support boss levels

[Update history]
2020/12/14 v1.2
- Bug fixed: restore the frog timer for level retry
- Bug fixed: stable best time update

2020/12/14 v1.1
- Now timer keep running during pausing or screen transitions for RTA-viable

2020/12/13 v1.0
- Initial release